from django.apps import AppConfig


class DjangoPopupViewFieldConfig(AppConfig):
    name = 'django_popup_view_field'
