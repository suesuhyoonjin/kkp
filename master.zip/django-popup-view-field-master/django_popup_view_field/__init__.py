VERSION = (0, 6, 1)
__version__ = ".".join(str(i) for i in VERSION)
SUPPORTED_BOOTSTRAP_VER = ('bootstrap3', 'bootstrap4')
